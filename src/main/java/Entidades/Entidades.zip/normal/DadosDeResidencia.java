package Entidades.normal;

public class DadosDeResidencia {
    private String uf;
    private String municipio;
    private String distrito;
    private String bairro;
    private String logradouro;
    private String numero;
    private String complemento;
    private String geoCampo1;
    private String geoCampo2;
    private String pontoReferencia;
    private String cep;
    private String telefone;
    private String zona;

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    public String getDistrito() {
        return distrito;
    }

    public void setDistrito(String distrito) {
        this.distrito = distrito;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getGeoCampo1() {
        return geoCampo1;
    }

    public void setGeoCampo1(String geoCampo1) {
        this.geoCampo1 = geoCampo1;
    }

    public String getGeoCampo2() {
        return geoCampo2;
    }

    public void setGeoCampo2(String geoCampo2) {
        this.geoCampo2 = geoCampo2;
    }

    public DadosDeResidencia(String pais, String zona, String telefone, String cep, String pontoReferencia, String geoCampo2, String geoCampo1, String complemento, String numero, String logradouro, String bairro, String distrito, String municipio, String uf) {
        this.pais = pais;
        this.zona = zona;
        this.telefone = telefone;
        this.cep = cep;
        this.pontoReferencia = pontoReferencia;
        this.geoCampo2 = geoCampo2;
        this.geoCampo1 = geoCampo1;
        this.complemento = complemento;
        this.numero = numero;
        this.logradouro = logradouro;
        this.bairro = bairro;
        this.distrito = distrito;
        this.municipio = municipio;
        this.uf = uf;
    }

    public String getPontoReferencia() {
        return pontoReferencia;
    }

    public void setPontoReferencia(String pontoReferencia) {
        this.pontoReferencia = pontoReferencia;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getZona() {
        return zona;
    }

    public void setZona(String zona) {
        this.zona = zona;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    private String pais;
}
